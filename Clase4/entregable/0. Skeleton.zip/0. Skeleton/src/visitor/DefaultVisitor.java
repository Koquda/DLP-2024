package visitor;

// This class will be implemented in syntax analysis phase

public class DefaultVisitor implements Visitor {

    // public Object visit(Program nodo, Object param) {
    // ...
    // }

}
