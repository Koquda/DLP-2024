package visitor;

// This class will be implemented in syntax analysis phase

public interface Visitor {
    // public Object visit(Program node, Object param);
}
