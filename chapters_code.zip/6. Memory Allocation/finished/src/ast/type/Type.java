// Generated with VGen 2.0.0

package ast.type;

import ast.*;

// %% User Declarations -------------

// Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	type -> 
*/
public interface Type extends AST {




    // %% User Members -------------------------

    public int getSize();

    // %% --------------------------------------
}
