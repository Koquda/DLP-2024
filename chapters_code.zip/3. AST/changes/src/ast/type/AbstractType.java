// Generated with VGen 2.0.0

package ast.type;

import ast.*;

// %% User Declarations -------------

    // Declarations (e.g. imports) in this section will be preserved. Delete if not needed

// %% -------------------------------

/*
	type -> 
*/
public abstract class AbstractType extends AbstractAST implements Type {




    // %% User Members -------------------------

        // Methods/attributes in this section will be preserved. Delete if not needed

    // %% --------------------------------------
}
